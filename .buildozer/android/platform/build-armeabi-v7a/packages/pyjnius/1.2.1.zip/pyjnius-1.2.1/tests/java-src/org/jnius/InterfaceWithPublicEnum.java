package org.jnius;


public interface InterfaceWithPublicEnum {

    public enum ATTITUDE {
        GOOD, BAD, UGLY,
    }
}
